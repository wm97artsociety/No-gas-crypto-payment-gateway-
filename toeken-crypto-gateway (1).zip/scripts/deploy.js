const hre = require("hardhat");

async function main() {
  const LazyMintNFT = await hre.ethers.getContractFactory("LazyMintNFT");
  const lazyMintNFT = await LazyMintNFT.deploy();
  await lazyMintNFT.deployed();
  console.log("LazyMintNFT deployed to:", lazyMintNFT.address);

  const ToekenToken = await hre.ethers.getContractFactory("ToekenToken");
  const toekenToken = await ToekenToken.deploy("1000000000000000000000000"); // 1M TOEKEN
  await toekenToken.deployed();
  console.log("ToekenToken deployed to:", toekenToken.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
