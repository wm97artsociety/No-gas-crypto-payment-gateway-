const express = require("express");
const { ethers } = require("ethers");
const settings = require("../config/settings.json");

const app = express();
const PORT = process.env.PORT || 3000;

// Set up provider for the first chain in settings
const chain = settings.chains[0];
const provider = new ethers.providers.JsonRpcProvider(chain.rpc);

app.get("/health", (req, res) => {
  res.send("TOEKEN Payment Gateway Server is running.");
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
